import flet as ft


def main(page: ft.Page):
    page.title = "alioooowwwwhcg.ir"
    page.rtl = True
    page.padding = 0
    page.bgcolor = "#08111F"
    page.scroll = ft.ScrollMode.AUTO

    def go_home(e=None):
        page.controls.clear()
        page.add(home_view())
        page.update()

    def go_about(e=None):
        page.controls.clear()
        page.add(about_view())
        page.update()

    def go_contact(e=None):
        page.controls.clear()
        page.add(contact_view())
        page.update()

    def nav():
        return ft.Container(
            padding=ft.Padding(20, 16, 20, 16),
            bgcolor="#0B1728",
            content=ft.Row(
                controls=[
                    ft.Text(
                        "alioooowwwwhcg.ir",
                        size=20,
                        weight=ft.FontWeight.BOLD,
                        color="#67E8F9",
                    ),
                    ft.Container(expand=True),
                    ft.TextButton(content="خانه", on_click=go_home),
                    ft.TextButton(content="درباره", on_click=go_about),
                    ft.TextButton(content="ارتباط", on_click=go_contact),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def home_view():
        return ft.Column(
            controls=[
                nav(),
                ft.Container(
                    expand=True,
                    padding=ft.Padding(25, 70, 25, 70),
                    alignment=ft.Alignment(0, 0),
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=18,
                        controls=[
                            ft.Container(
                                padding=ft.Padding(14, 8, 14, 8),
                                border=ft.Border.all(1, "#31516F"),
                                border_radius=30,
                                bgcolor="#102238",
                                content=ft.Text(
                                    "به سایت من خوش آمدید",
                                    color="#8EE6FF",
                                    size=16,
                                ),
                            ),
                            ft.Text(
                                "alioooowwwwhcg.ir",
                                size=48,
                                weight=ft.FontWeight.BOLD,
                                color="#F5FAFF",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "یک سایت ساخته‌شده با Flet",
                                size=22,
                                color="#B9C8D9",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "ساده، سریع و آماده‌ی انتشار در وب",
                                size=17,
                                color="#8495A9",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Button(
                                content="درباره سایت",
                                icon=ft.Icons.INFO_OUTLINE,
                                bgcolor="#38BDF8",
                                color="#04111C",
                                on_click=go_about,
                            ),
                        ],
                    ),
                ),
                footer(),
            ],
        )

    def about_view():
        return ft.Column(
            controls=[
                nav(),
                ft.Container(
                    padding=ft.Padding(30, 70, 30, 70),
                    content=ft.Column(
                        spacing=20,
                        controls=[
                            ft.Text(
                                "درباره سایت",
                                size=36,
                                weight=ft.FontWeight.BOLD,
                                color="#73DDFF",
                            ),
                            ft.Text(
                                "این وب‌سایت با Python و Flet ساخته شده است.",
                                size=20,
                                color="#E8F1FA",
                            ),
                            ft.Text(
                                "می‌توانی این صفحه را برای معرفی خودت، پروژه‌ها، "
                                "بازی‌ها، عکس‌ها یا مطالب دلخواهت تغییر بدهی.",
                                size=17,
                                color="#B9C8D9",
                            ),
                            ft.Button(
                                content="بازگشت به خانه",
                                icon=ft.Icons.HOME_OUTLINED,
                                on_click=go_home,
                            ),
                        ],
                    ),
                ),
                footer(),
            ],
        )

    def contact_view():
        return ft.Column(
            controls=[
                nav(),
                ft.Container(
                    padding=ft.Padding(30, 70, 30, 70),
                    content=ft.Column(
                        spacing=20,
                        controls=[
                            ft.Text(
                                "ارتباط",
                                size=36,
                                weight=ft.FontWeight.BOLD,
                                color="#73DDFF",
                            ),
                            ft.Text(
                                "اطلاعات تماس خودت را می‌توانی در این قسمت قرار بدهی.",
                                size=18,
                                color="#B9C8D9",
                            ),
                            ft.TextField(
                                label="پیام آزمایشی",
                                hint_text="پیامت را بنویس...",
                                multiline=True,
                                min_lines=4,
                                border_radius=12,
                            ),
                            ft.Button(
                                content="ارسال آزمایشی",
                                icon=ft.Icons.SEND,
                                bgcolor="#38BDF8",
                                color="#04111C",
                                on_click=lambda e: page.show_dialog(
                                    ft.AlertDialog(
                                        title=ft.Text("انجام شد"),
                                        content=ft.Text(
                                            "این دکمه فعلاً آزمایشی است."
                                        ),
                                    )
                                ),
                            ),
                        ],
                    ),
                ),
                footer(),
            ],
        )

    def footer():
        return ft.Container(
            padding=ft.Padding(20, 30, 20, 30),
            bgcolor="#0B1728",
            alignment=ft.Alignment(0, 0),
            content=ft.Text(
                "© 2026 alioooowwwwhcg.ir",
                color="#8495A9",
                text_align=ft.TextAlign.CENTER,
            ),
        )

    page.add(home_view())


ft.run(main)
