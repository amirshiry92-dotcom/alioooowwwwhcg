# alioooowwwwhcg.ir - Flet Static Website

## اجرای محلی

```bash
python -m pip install --upgrade flet
flet run --web main.py
```

## ساخت سایت استاتیک

```bash
flet publish main.py
```

خروجی پیش‌فرض داخل پوشه `dist` ساخته می‌شود.

## تست خروجی

```bash
flet serve dist
```

سپس آدرس localhost که Flet نمایش می‌دهد را در مرورگر باز کن.

## انتشار رایگان

می‌توانی پوشه خروجی `dist` را با GitHub Pages منتشر کنی.
برای دامنه اختصاصی، بعداً باید دامنه را به GitHub Pages متصل کنی.

نکته: برای اجرای Static، Python و وابستگی‌های پروژه در مرورگر با Pyodide اجرا می‌شوند.
